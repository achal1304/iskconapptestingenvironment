# ISKCON Pune Flutter App

A new Flutter project.

## About this Project

- This is the source code for the ISKCON Pune App.
- It has Google Firebase Integration.
- It uses Cloud Firestore Realtime Database at the back-end.
- It uses Firebase Storage to store data(audio/images).
- It has two views: 
           1.Normal User View
           2.Admin View
- It uses FCM for push notifications
- This code was written by Shreyash Pardkar for the ISKCON Internship Program.
